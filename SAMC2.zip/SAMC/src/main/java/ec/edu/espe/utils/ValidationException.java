package ec.edu.espe.utils;

public class ValidationException extends Exception {

    public ValidationException(String message) {
        super(message);
    }
}
