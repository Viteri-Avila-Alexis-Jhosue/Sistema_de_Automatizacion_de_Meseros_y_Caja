/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package ec.edu.espe.view;

/**
 *
 * @author Camila Bohorquez
 */
public class SAMCApp {
    
    public static void main(String[] args) {
        //PRIMERA VENTANA TIPO DE CUENTA (TYPEACCOUNT)
        new FrmTypeAccount().setVisible(true);
    }
}
