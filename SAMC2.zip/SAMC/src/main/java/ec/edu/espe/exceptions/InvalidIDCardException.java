package ec.edu.espe.exceptions;

public class InvalidIDCardException extends Exception {
    public InvalidIDCardException(String message) {
        super(message);
    }
}

